<?php

class Admin_Block_Login extends Core_Block_Template{
    
}