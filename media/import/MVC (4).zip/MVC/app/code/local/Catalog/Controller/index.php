<?php
class Catalog_Controller_index extends Core_Controller_Front_Action{
    
}
?>