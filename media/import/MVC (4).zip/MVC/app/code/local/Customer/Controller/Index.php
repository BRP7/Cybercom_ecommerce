<?php

class Customer_Controller_Index extends Core_Controller_Front_Action
{
    public function newAction()
    {
        echo "Address New Action";
    }
    public function listAction()
    {
        echo "Address New Action";
    }
    public function saveAction()
    {
        echo "Address New Action";
    }
    public function deleteAction()
    {
        echo "Address New Action";
    }

}