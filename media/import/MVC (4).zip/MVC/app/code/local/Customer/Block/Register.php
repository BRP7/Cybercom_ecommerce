<?php
class Customer_Block_Register extends Core_Block_Template{
    
}