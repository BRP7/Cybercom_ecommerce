<?php
class Customer_BLock_Login extends Core_Block_Template{

}