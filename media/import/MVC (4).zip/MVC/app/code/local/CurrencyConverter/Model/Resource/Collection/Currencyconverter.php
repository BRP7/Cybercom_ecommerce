<?php

class Currencyconverter_Model_Resource_Collection_Currencyconverter extends Core_Model_Resource_Collection_Abstract{

    
}