<?php

class Currencyconverter_Model_Resource_Collection_Currency extends Core_Model_Resource_Collection_Abstract{

    
}