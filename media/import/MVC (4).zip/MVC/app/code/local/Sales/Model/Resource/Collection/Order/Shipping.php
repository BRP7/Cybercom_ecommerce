<?php

class Sales_Model_Resource_Collection_Order_Shipping extends Core_Model_Resource_Collection_Abstract{

    
}
?>