<?php

class Sales_Block_Quote extends Core_Block_Template{

  
}
?>