<?php

include "app/code/local/autoload.php";
include "app/Mage.php";

Mage::init();




